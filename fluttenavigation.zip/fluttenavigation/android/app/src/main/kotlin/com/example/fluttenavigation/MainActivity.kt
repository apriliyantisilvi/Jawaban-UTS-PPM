package com.example.fluttenavigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
